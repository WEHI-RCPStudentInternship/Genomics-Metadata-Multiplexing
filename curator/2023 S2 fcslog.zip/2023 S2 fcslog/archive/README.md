# archive

The ```archive``` directory involves **UNUSED** code by the 2023 Semester 2 intake.

The 2023 Semester 2 intake **FAILED** to implement a fully functional frontend and backend and hence their deprication.

> NOTE: Please do **NOT delete** any assets within this directory
