# design_1

Welcome to the ```design_1```, this implementation uses [FCSParser](https://pypi.org/project/fcsparser/) and is **NOT** currently used. For more information, refer to the [Design 1](https://github.com/WEHI-ResearchComputing/Genomics-Metadata-Multiplexing/wiki/FCSLOG#design-1) section within the [FCSLog](https://github.com/WEHI-ResearchComputing/Genomics-Metadata-Multiplexing/wiki/FCSLOG) wiki page.

This markdown file contains the following contents:
1. [Directory Structure](#directory-structure): 
2. [Things To Fix](#things-to-fix): 

## Directory Structure


## Things To Fix
