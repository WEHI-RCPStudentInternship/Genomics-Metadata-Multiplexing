# design_2

Welcome to the ```design_2```, this implementation uses [FlowJo](https://www.flowjo.com/) and serves as the **CURRENT** design. For more information, refer to the [Design 1](https://github.com/WEHI-ResearchComputing/Genomics-Metadata-Multiplexing/wiki/FCSLOG#design-2) section within the [FCSLog](https://github.com/WEHI-ResearchComputing/Genomics-Metadata-Multiplexing/wiki/FCSLOG) wiki page.

This markdown file contains the following contents:
1. [Directory Structure](#directory-structure): 
2. [Things To Fix](#things-to-fix): 

## Directory Structure


## Things To Fix
